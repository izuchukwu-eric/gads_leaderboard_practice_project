package com.example.leaderboard;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.leaderboard.services.ServiceBuilder;
import com.example.leaderboard.services.SubmitService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProjectSubmissionActivity extends AppCompatActivity {
    private static final String TAG = "ProjectSubmission";
    Dialog epicDialog;
    private Button popupBtn;
    private TextView popupTitle, popupSuccessText, popupFailureText;
    private ImageView closePopupSubmitImg, popupCheckImg, popupWarningImg;
    private Button submit;
    private EditText txtName;
    private EditText txtLastName;
    private EditText txtEmail;
    private EditText txtGithub;
    private SubmitService mSubmitService;
    private String firstName;
    private String lastName;
    private String email;
    private String githubLink;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_submission);

        epicDialog = new Dialog(this);


        txtName = (EditText) findViewById(R.id.txtName);
        txtLastName = (EditText) findViewById(R.id.txtLastName);
        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtGithub = (EditText) findViewById(R.id.txtGithub);

        mSubmitService = ServiceBuilder.getSubmitService();

        submit = (Button) findViewById(R.id.button);
        submit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                firstName = txtName.getText().toString();
                lastName = txtLastName.getText().toString();
                email = txtEmail.getText().toString();
                githubLink = txtGithub.getText().toString();

               if (!firstName.isEmpty() && !lastName.isEmpty() && !email.isEmpty() && !githubLink.isEmpty()) {
                   showSubmitPopup();

               } else {
                   Toast.makeText(ProjectSubmissionActivity.this, "Please Fill All Fields", Toast.LENGTH_SHORT)
                           .show();
               }

            }

            private void showSubmitPopup() {
                epicDialog.setContentView(R.layout.custom_popup_submit);
                closePopupSubmitImg = (ImageView) epicDialog.findViewById(R.id.closePopupSubmitImg);
                popupBtn = (Button) epicDialog.findViewById(R.id.popupBtn);
                popupTitle = (TextView) epicDialog.findViewById(R.id.popupTitle);


                closePopupSubmitImg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        epicDialog.dismiss();
                    }
                });
                popupBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        sendPost(firstName, lastName, email, githubLink);
                    }
                });

                epicDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                epicDialog.show();
            }

            private void sendPost(String firstName, String lastName, final String email, String githubLink) {
                mSubmitService.submitProject(firstName, lastName, email, githubLink).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response ) {
                        if (response.isSuccessful()) {
                            showSuccessPopup();
                            Log.i(TAG, "Project submitted to API." + response.message());
                        }
                    }

                    private void showSuccessPopup() {
                        epicDialog.setContentView(R.layout.custom_popup_success);
                        popupCheckImg = (ImageView) epicDialog.findViewById(R.id.popupCheckImg);
                        popupSuccessText = (TextView) epicDialog.findViewById(R.id.popupSuccessText);

                        epicDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        epicDialog.show();
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        showFailurePopup();
                        Log.e(TAG, "Unable to submit project to API." + t.getMessage());
                    }

                    private void showFailurePopup() {
                        epicDialog.setContentView(R.layout.custom_popup_failure);
                        popupWarningImg = (ImageView) epicDialog.findViewById(R.id.popupWarningImg);
                        popupFailureText = (TextView) epicDialog.findViewById(R.id.popupFailureText);

                        epicDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        epicDialog.show();
                    }
                });
            }

        });


  }

}
