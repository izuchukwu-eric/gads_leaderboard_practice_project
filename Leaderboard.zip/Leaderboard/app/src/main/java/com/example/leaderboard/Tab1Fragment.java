package com.example.leaderboard;

import android.app.Activity;
import android.content.Context;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;




public class Tab1Fragment extends Fragment {
    private static final String TAG = "Tab1Fragment";
    public TextView textTab1;
    private TextView tv_error;
    private ProgressBar mLoadingProgress;
    private RecyclerView rv_learners;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab1_fragment, container, false);
        mLoadingProgress = (ProgressBar) getActivity().findViewById(R.id.pb_loading);
        rv_learners = (RecyclerView) view.findViewById(R.id.rv_leaners);
        try {
            URL learningUrl = ApiUtil.buildUrl("hours");
            new LearningQueryTask().execute(learningUrl);
        }
        catch (Exception e){
            Log.d("error", e.getMessage());
        }
        return view;
    }

    public class LearningQueryTask extends AsyncTask<URL, Void, String> {


        @Override
        protected String doInBackground(URL... urls) {
            URL searchURL = urls[0];
            String result = "";
            try {
                result = ApiUtil.getJson(searchURL);
            }
            catch (IOException e){
                Log.e("Error", e.getMessage());
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            tv_error = (TextView) getActivity().findViewById(R.id.tv_error);
            tv_error.setVisibility(View.VISIBLE);
            mLoadingProgress.setVisibility(View.INVISIBLE);

            if (result == "") {
                rv_learners.setVisibility(View.INVISIBLE);

            }
            else {
                rv_learners.setVisibility(View.VISIBLE);
                tv_error.setVisibility(View.INVISIBLE);
            }
            ArrayList<Learners> learners = ApiUtil.getLearnersFromJson(result);
            String resultString = "";
            LearnersAdapter adapter = new LearnersAdapter(learners);
            rv_learners.setAdapter(adapter);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mLoadingProgress.setVisibility(View.VISIBLE);
        }
    }
}
