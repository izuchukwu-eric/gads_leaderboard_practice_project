package com.example.leaderboard;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class Tab2Fragment extends Fragment {
    private static final String TAG = "Tab2Fragment";

    private TextView textTab2;
    private ProgressBar mLoadingProgress;
    private RecyclerView rv_skill;
    private TextView tv_error;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab2_fragment, container, false);
        mLoadingProgress = (ProgressBar) getActivity().findViewById(R.id.pb_loading);
        rv_skill = (RecyclerView) view.findViewById(R.id.rv_skill);
        try {
            URL learningUrl = SkillUtil.buildUrl("skilliq");
            new SkillIqQueryTask().execute(learningUrl);

        } catch (Exception e) {
            Log.d("error", e.getMessage());
        }
        return view;
    }

    public class SkillIqQueryTask extends AsyncTask<URL, Void, String>{

        @Override
        protected String doInBackground(URL... urls) {
            URL searchURL = urls[0];
            String result = "";
            try {
                result = SkillUtil.getJson(searchURL);
            }
            catch (IOException e){
                Log.e("Error", e.getMessage());
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            tv_error = (TextView) getActivity().findViewById(R.id.tv_error);
            mLoadingProgress.setVisibility(View.INVISIBLE);

            if (result == "") {
                rv_skill.setVisibility(View.INVISIBLE);
                tv_error.setVisibility(View.VISIBLE);
            }
            else {
                rv_skill.setVisibility(View.VISIBLE);
                tv_error.setVisibility(View.INVISIBLE);
            }
            ArrayList<SkillLeaders> skillLeaders = SkillUtil.getSkillLeadersFromJson(result);
            String resultString = "";
            SkillAdapter adapter = new SkillAdapter(skillLeaders);
            rv_skill.setAdapter(adapter);

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mLoadingProgress.setVisibility(View.VISIBLE);
        }
    }
}

