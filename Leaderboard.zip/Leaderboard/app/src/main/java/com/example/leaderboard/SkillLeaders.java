package com.example.leaderboard;

public class SkillLeaders {
    public final String names;
    public final String scores;
    public final String country;

    public SkillLeaders(String names, String scores, String country) {
        this.names = names;
        this.scores = scores;
        this.country = country;
    }

    public String getNames() { return names;}

    public String getScores() { return scores;}

    public String getCountry() { return country;}
}
