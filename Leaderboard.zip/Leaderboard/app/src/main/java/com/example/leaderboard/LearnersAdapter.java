package com.example.leaderboard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LearnersAdapter extends RecyclerView.Adapter<LearnersAdapter.LearnersViewHolder>{

    ArrayList<Learners> learners;
    public LearnersAdapter(ArrayList<Learners> learners) {
        this.learners = learners;
    }
    @NonNull
    @Override
    public LearnersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.learning_leaders, parent, false);
        return new LearnersViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull LearnersViewHolder holder, int position) {
        Learners learner = learners.get(position);
        holder.bind(learner);
    }

    @Override
    public int getItemCount() {
        return learners.size();
    }

    public class LearnersViewHolder extends RecyclerView.ViewHolder {

        TextView tvName;
        TextView tvHours;
        TextView tvCountry;
        public LearnersViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = (TextView) itemView.findViewById(R.id.tvName);
            tvHours = (TextView) itemView.findViewById(R.id.tvHours);
            tvCountry = (TextView) itemView.findViewById(R.id.tvCountry);
        }
        public void bind(Learners learners) {
            tvName.setText(learners.names);
            tvHours.setText(learners.hours);
            tvCountry.setText(learners.country);
        }
    }
}
