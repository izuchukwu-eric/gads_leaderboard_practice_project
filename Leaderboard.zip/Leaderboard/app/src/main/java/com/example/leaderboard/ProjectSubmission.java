package com.example.leaderboard;

public class ProjectSubmission {
        public final String firstName;
        public final String lastName;
        public final String email;
        public final String githubLink;



    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getGithubLink() {
        return githubLink;
    }

    public ProjectSubmission(String firstName, String lastName, String email, String githubLink) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.githubLink = githubLink;
    }




}
