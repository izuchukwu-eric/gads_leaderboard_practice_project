package com.example.leaderboard;

public class Learners {
    public final String names;
    public final String hours;
    public final String country;

    public Learners( String names, String hours, String country) {
        this.names = names;
        this.hours = hours;
        this.country = country;
    }



    public String getNames() { return  names;}

    public String getHours() { return hours;}

    public String getCountry() { return country;}
}
